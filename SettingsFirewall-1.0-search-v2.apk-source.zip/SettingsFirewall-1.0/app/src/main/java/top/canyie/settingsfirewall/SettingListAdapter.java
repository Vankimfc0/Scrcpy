package top.canyie.settingsfirewall;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Filter;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * @author canyie
 */
public class SettingListAdapter extends ArrayAdapter<Replacement> {
    private final SettingsEditActivity activity;
    private final List<Replacement> allItems = new ArrayList<>();
    private final Filter filter = new Filter() {
        @Override protected FilterResults performFiltering(CharSequence constraint) {
            String query = constraint == null ? "" :
                    constraint.toString().trim().toLowerCase(Locale.ROOT);

            List<Replacement> result = new ArrayList<>();
            if (query.isEmpty()) {
                result.addAll(allItems);
            } else {
                for (Replacement item : allItems) {
                    String key = item.key == null ? "" : item.key.toLowerCase(Locale.ROOT);
                    String value = item.value == null ? "" : item.value.toLowerCase(Locale.ROOT);
                    if (key.contains(query) || value.contains(query)) {
                        result.add(item);
                    }
                }
            }

            FilterResults results = new FilterResults();
            results.values = result;
            results.count = result.size();
            return results;
        }

        @Override protected void publishResults(CharSequence constraint, FilterResults results) {
            clear();
            if (results.values != null) {
                //noinspection unchecked
                addAll((List<Replacement>) results.values);
            }
            notifyDataSetChanged();
        }
    };

    public SettingListAdapter(SettingsEditActivity activity, List<Replacement> list) {
        super(activity, 0, new ArrayList<>(list));
        this.activity = activity;
        allItems.addAll(list);
    }

    @Override public Filter getFilter() {
        return filter;
    }

    @Override public void notifyDataSetChanged() {
        super.notifyDataSetChanged();
    }

    @Override public View getView(int position, View convertView, ViewGroup parent) {
        var replacement = getItem(position);
        assert replacement != null;
        ViewHolder viewHolder;
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.setting_item, parent, false);
            viewHolder = new ViewHolder();
            viewHolder.key = convertView.findViewById(R.id.key);
            viewHolder.replacement = convertView.findViewById(R.id.replacement);
            convertView.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) convertView.getTag();
        }
        convertView.setOnClickListener(v -> activity.onItemClicked(replacement));
        viewHolder.key.setText(replacement.key);
        if (replacement.value != null) {
            viewHolder.replacement.setVisibility(View.VISIBLE);
            viewHolder.replacement.setText(getContext().getString(R.string.replaced_with, replacement.value));
        } else {
            viewHolder.replacement.setVisibility(View.GONE);
        }
        return convertView;
    }

    private static class ViewHolder {
        TextView key;
        TextView replacement;
    }
}
