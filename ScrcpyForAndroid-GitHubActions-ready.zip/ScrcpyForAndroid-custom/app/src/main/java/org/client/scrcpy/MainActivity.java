package org.client.scrcpy;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.ActivityInfo;
import android.content.res.AssetManager;
import android.content.res.Configuration;
import android.graphics.Color;
import android.database.Cursor;
import android.graphics.drawable.GradientDrawable;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.net.Uri;
import android.provider.OpenableColumns;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.os.SystemClock;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.Surface;
import android.view.SurfaceView;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.ListPopupWindow;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.Toast;

import org.client.scrcpy.utils.AdbHelper;
import org.client.scrcpy.utils.HttpRequest;
import org.client.scrcpy.utils.PreUtils;
import org.client.scrcpy.utils.Progress;
import org.client.scrcpy.utils.ThreadUtils;
import org.client.scrcpy.utils.Util;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.OutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.concurrent.TimeUnit;


public class MainActivity extends Activity implements Scrcpy.ServiceCallbacks, SensorEventListener {

    // 是否直接连接远程
    public final static String START_REMOTE = "start_remote_headless";

    private boolean headlessMode = false;  // 是否为无头模式，不显示操作选项等
    private int screenWidth;
    private int screenHeight;
    private boolean landscape = false;
    private boolean first_time = true;
    private boolean result_of_Rotation = false;
    private boolean serviceBound = false;
    // 如果 pause 切换到后台，断开后，自动重连
    // 该状态禁止保存恢复
    private boolean resumeScrcpy = false;
    SensorManager sensorManager;
    private SendCommands sendCommands;
    private int videoBitrate;
    private int videoMaxSize = 0;
    private int videoFps = 60;
    private int delayControl;
    private static final int REQ_INSTALL_APK = 4101;
    private static final int REQ_PUSH_FILE = 4102;
    private String lastConnectedServer = null;
    private String recordingRemotePath = null;
    private Context context;
    private String serverAdr = null;
    private SurfaceView surfaceView;
    private Surface surface;
    private Scrcpy scrcpy;
    private long timestamp = 0;

    // private byte[] fileBase64;
    private LinearLayout linearLayout;

    private final ServiceConnection serviceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName componentName, IBinder iBinder) {
            scrcpy = ((Scrcpy.MyServiceBinder) iBinder).getService();
            scrcpy.setServiceCallbacks(MainActivity.this);
            serviceBound = true;
            if (first_time) {
                if (!Progress.isShowing()) {
                    Progress.showDialog(MainActivity.this, getString(R.string.please_wait));
                }
                scrcpy.start(surface, Scrcpy.LOCAL_IP + ":" + Scrcpy.LOCAL_FORWART_PORT,
                        screenHeight, screenWidth, delayControl);
                ThreadUtils.workPost(() -> {
                    boolean success = AdbHelper.executeWithTimeout(() -> {
                        while (!scrcpy.check_socket_connection()) {
                            try {
                                Thread.sleep(10);
                            } catch (InterruptedException e) {
                                break;
                            }
                        }
                    }, SendCommands.WAIT_TIME, TimeUnit.MILLISECONDS);
                    ThreadUtils.post(() -> {
                        Progress.closeDialog();
                        if (!success) {
                            if (serviceBound) {
                                showMainView();
                            }
                            Toast.makeText(context, "Connection Timed out 2", Toast.LENGTH_SHORT).show();
                        } else {
                            first_time = false;
                            // 连接成功后，再把按钮显示出来
                            set_display_nd_touch();
                            connectSuccessExt();
                        }
                    });
                });
            } else {
                scrcpy.setParms(surface, screenWidth, screenHeight);
                set_display_nd_touch();
                connectSuccessExt();
            }
            // set_display_nd_touch();
        }

        @Override
        public void onServiceDisconnected(ComponentName componentName) {
            serviceBound = false;
        }
    };

    private void showMainView() {
        showMainView(false);
    }

    // userDisconnect ：是否为用户手动断开连接
    private void showMainView(boolean userDisconnect) {
        if (scrcpy != null) {
            scrcpy.StopService();
        }
        try {
            // 可能会导致重复解绑，所以捕获异常
            unbindService(serviceConnection);
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (surface != null) {
            surface = null;
        }
        if (surfaceView != null) {
            surfaceView = null;
        }
        serviceBound = false;
        scrcpy_main();

        if (scrcpy != null) {
            scrcpy = null;
        }
        // 退出连接，需要处理额外的事件
        connectExitExt(userDisconnect);
    }

    @SuppressLint("SourceLockedOrientationActivity")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.context = this;
        if (savedInstanceState != null) {
            first_time = savedInstanceState.getBoolean("first_time");
            landscape = savedInstanceState.getBoolean("landscape");
            headlessMode = savedInstanceState.getBoolean("headlessMode");
            resumeScrcpy = savedInstanceState.getBoolean("resumeScrcpy");
            screenHeight = savedInstanceState.getInt("screenHeight");
            screenWidth = savedInstanceState.getInt("screenWidth");
            videoMaxSize = savedInstanceState.getInt("videoMaxSize", videoMaxSize);
        }
        // 读取屏幕是横屏、还是竖屏
        landscape = getApplication().getResources().getConfiguration().orientation
                != Configuration.ORIENTATION_PORTRAIT;
        if (first_time) {
            scrcpy_main();
        } else {
            Log.e("Scrcpy: ", "from onCreate");
            start_screen_copy_magic();
        }
        sensorManager = (SensorManager) this.getSystemService(SENSOR_SERVICE);
        Sensor proximity;
        proximity = sensorManager.getDefaultSensor(Sensor.TYPE_PROXIMITY);
        sensorManager.registerListener(this, proximity, SensorManager.SENSOR_DELAY_NORMAL);

        if (savedInstanceState != null) {
            Log.i("Scrcpy", "outState: " + savedInstanceState.getBoolean("from_save_instance"));
        }
        // 从销毁状态恢复
        if (savedInstanceState == null || !savedInstanceState.getBoolean("from_save_instance", false)) {
            // 初次进入 app
            if (getIntent() != null && getIntent().getExtras() != null) {
                headlessMode = getIntent().getExtras().getBoolean(START_REMOTE, headlessMode);
            }
        }
        if (headlessMode && first_time) {
            getAttributes();
            connectScrcpyServer(PreUtils.get(this, Constant.CONTROL_REMOTE_ADDR, ""));
        }
        if (headlessMode) {
            View scrollView = findViewById(R.id.main_scroll_view);
            if (scrollView != null) {
                scrollView.setVisibility(View.INVISIBLE);
            }
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        Log.i("Scrcpy", "enter onSaveInstanceState");
        outState.putBoolean("from_save_instance", true);
        outState.putBoolean("first_time", first_time);
        outState.putBoolean("landscape", landscape);
        outState.putBoolean("headlessMode", headlessMode);  // 第二次进入时，intent会被重置，需要保存状态
        // 小窗模式、半屏模式切换避免恢复横竖屏，会导致黑屏（因为scrcpy恢复的resume只允许一次连接）
        // outState.putBoolean("resumeScrcpy", resumeScrcpy);
        outState.putInt("screenHeight", screenHeight);
        outState.putInt("screenWidth", screenWidth);
        outState.putInt("videoMaxSize", videoMaxSize);
    }

    @SuppressLint("SourceLockedOrientationActivity")
    public void scrcpy_main() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            this.getWindow().setStatusBarColor(getColor(R.color.status_bar));
        } else {
            this.getWindow().setStatusBarColor(getResources().getColor(R.color.status_bar));
        }
        final View decorView = getWindow().getDecorView();
        decorView.setSystemUiVisibility(View.VISIBLE);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        landscape = false;  // 将模式重新置为 竖屏，模式不正确将导致连接黑屏
        setContentView(R.layout.activity_main);
        final Button startButton = findViewById(R.id.button_start);
        // final Button floatButton = findViewById(R.id.button_start_float);

        sendCommands = new SendCommands();

        startButton.setOnClickListener(v -> {
            // local_ip = wifiIpAddress();
            getAttributes();
            connectScrcpyServer(serverAdr);
        });

//        floatButton.setOnClickListener(v -> {
//            getAttributes();
//            showDisplayWindow();
//        });
        get_saved_preferences();
        setupSmartUi();

        EditText editText = findViewById(R.id.editText_server_host);

        findViewById(R.id.history_list).setOnClickListener(v -> {
            Log.i("Scrcpy", "focus true");
            editText.clearFocus();
            showListPopulWindow(editText);
        });

        // 无头模式，实际上要隐藏掉所有控件，否则会被显示出 ip 地址
        if (headlessMode) {
            View scrollView = findViewById(R.id.main_scroll_view);
            if (scrollView != null) {
                scrollView.setVisibility(View.INVISIBLE);
            }
        }
    }

    private void showListPopulWindow(EditText mEditText) {
        String[] list = getHistoryList();//要填充的数据
        if (list.length == 0) {  // 如果list为空，则使用本机填充一个
            list = new String[]{"127.0.0.1"};
        }
        final ListPopupWindow listPopupWindow;
        listPopupWindow = new ListPopupWindow(this);
        listPopupWindow.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, list));//用android内置布局，或设计自己的样式
        listPopupWindow.setAnchorView(mEditText);//以哪个控件为基准，在该处以mEditText为基准
        listPopupWindow.setModal(true);
        listPopupWindow.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);

        String[] finalList = list;
        listPopupWindow.setOnItemClickListener(new AdapterView.OnItemClickListener() {//设置项点击监听
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                mEditText.setText(finalList[i]);
                listPopupWindow.dismiss();
            }
        });
        listPopupWindow.show();
    }


//    private void showDisplayWindow() {
//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
//            if (!Settings.canDrawOverlays(this)) {
//                //启动Activity让用户授权
//                Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION);
//                startActivity(intent);
//                return;
//            }
//        }
//        Intent it = new Intent(this, FloatService.class);
//        it.putExtra("ip", serverAdr);
//        it.putExtra("w", screenWidth);
//        it.putExtra("h", screenHeight);
//        it.putExtra("b", videoBitrate);
//        startService(it);
//        finish();
//    }


    public void get_saved_preferences() {
        final EditText editTextServerHost = findViewById(R.id.editText_server_host);
        final Switch aSwitch0 = findViewById(R.id.switch0);
        final Switch aSwitch1 = findViewById(R.id.switch1);
        String historySpServerAdr = PreUtils.get(context, Constant.CONTROL_REMOTE_ADDR, "");
        if (TextUtils.isEmpty(historySpServerAdr)) {
            String[] historyList = getHistoryList();
            if (historyList.length > 0) {
                editTextServerHost.setText(historyList[0]);
            }
        } else {
            editTextServerHost.setText(historySpServerAdr);
        }
        aSwitch0.setChecked(PreUtils.get(context, Constant.CONTROL_NO, false));
        aSwitch1.setChecked(PreUtils.get(context, Constant.CONTROL_NAV, true));
        setSpinner(R.array.options_resolution_values, R.id.spinner_video_resolution, Constant.PREFERENCE_SPINNER_RESOLUTION);
        setSpinner(R.array.options_bitrate_keys, R.id.spinner_video_bitrate, Constant.PREFERENCE_SPINNER_BITRATE);
        setSpinner(R.array.options_fps_keys, R.id.spinner_video_fps, Constant.PREFERENCE_SPINNER_FPS);
        setSpinner(R.array.options_codec_keys, R.id.spinner_video_codec, Constant.PREFERENCE_SPINNER_CODEC);
        setSpinner(R.array.options_delay_keys, R.id.delay_control_spinner, Constant.PREFERENCE_SPINNER_DELAY);
        if (aSwitch0.isChecked()) {
            aSwitch1.setClickable(false);
            aSwitch1.setTextColor(Color.GRAY);
            // aSwitch1.setVisibility(View.GONE);
        }

        aSwitch0.setOnClickListener(v -> {
            if (aSwitch0.isChecked()) {
                aSwitch1.setClickable(false);
                aSwitch1.setTextColor(Color.GRAY);
                // aSwitch1.setVisibility(View.GONE);
            } else {
                aSwitch1.setClickable(true);
                aSwitch1.setTextColor(Color.rgb(32, 33, 36));
                // aSwitch1.setVisibility(View.VISIBLE);
            }
        });
    }

    @SuppressLint("ClickableViewAccessibility")
    public void set_display_nd_touch() {
        DisplayMetrics metrics = new DisplayMetrics();
        if (ViewConfiguration.get(context).hasPermanentMenuKey()) {
            getWindowManager().getDefaultDisplay().getMetrics(metrics);
        } else {
            final Display display = getWindowManager().getDefaultDisplay();
            display.getRealMetrics(metrics);
        }
//        float this_dev_height = metrics.heightPixels;
//        float this_dev_width = metrics.widthPixels;

        float this_dev_height = linearLayout.getHeight();
        float this_dev_width = linearLayout.getWidth();
        if (PreUtils.get(context, Constant.CONTROL_NAV, false) &&
                !PreUtils.get(context, Constant.CONTROL_NO, false)) {
            if (landscape) {
                this_dev_width = this_dev_width - 96;
            } else {                                                 //100 is the height of nav bar but need multiples of 8.
                this_dev_height = this_dev_height - 96;
            }
        }
        int[] rem_res = scrcpy.get_remote_device_resolution();
        int remote_device_height = rem_res[1];
        int remote_device_width = rem_res[0];
        float remote_device_aspect_ratio = (float) remote_device_height / remote_device_width;

        if (!landscape) {                                                            //Portrait
            float this_device_aspect_ratio = this_dev_height / this_dev_width;
//            Log.d("fuck", "set_display_nd_touch: "+this_device_aspect_ratio);
            if (remote_device_aspect_ratio > this_device_aspect_ratio) {
                //TODO
                float wantWidth = this_dev_height / remote_device_aspect_ratio;
                int padding = (int) (this_dev_width - wantWidth) / 2;
                linearLayout.setPadding(padding, 0, padding, 0);
            } else if (remote_device_aspect_ratio < this_device_aspect_ratio) {
                linearLayout.setPadding(0, (int) (((this_device_aspect_ratio - remote_device_aspect_ratio) * this_dev_width)), 0, 0);
            }

        } else {                                                                        //Landscape
            float this_device_aspect_ratio = this_dev_width / this_dev_height;
//            Log.d("fuck", "set_display_nd_touch_land: "+this_device_aspect_ratio);
            if (remote_device_aspect_ratio > this_device_aspect_ratio) {
                float wantHeight = this_dev_width / remote_device_aspect_ratio;
                int padding = (int) (this_dev_height - wantHeight) / 2;
                linearLayout.setPadding(0, padding, 0, padding);
            } else if (remote_device_aspect_ratio < this_device_aspect_ratio) {
                linearLayout.setPadding(((int) (((this_device_aspect_ratio - remote_device_aspect_ratio) * this_dev_height)) / 2), 0, ((int) (((this_device_aspect_ratio - remote_device_aspect_ratio) * this_dev_height)) / 2), 0);
            }

        }
        if (!PreUtils.get(context, Constant.CONTROL_NO, false)) {
            // Log.i("Screen", "setOnTouchListener: " + surfaceView.getWidth() + "x" + surfaceView.getHeight());
            surfaceView.setOnTouchListener((view, event) -> scrcpy.touchevent(event, landscape, surfaceView.getWidth(), surfaceView.getHeight()));
        }

        if (PreUtils.get(context, Constant.CONTROL_NAV, false) &&
                !PreUtils.get(context, Constant.CONTROL_NO, false)) {
            final View backButton = findViewById(R.id.back_button);
            final View homeButton = findViewById(R.id.home_button);
            final View appswitchButton = findViewById(R.id.appswitch_button);

            if (backButton != null) {
                backButton.setOnClickListener(v -> scrcpy.sendKeyevent(KeyEvent.KEYCODE_BACK));
            }
            if (homeButton != null) {
                homeButton.setOnClickListener(v -> scrcpy.sendKeyevent(KeyEvent.KEYCODE_HOME));
            }
            if (appswitchButton != null) {
                appswitchButton.setOnClickListener(v -> scrcpy.sendKeyevent(KeyEvent.KEYCODE_APP_SWITCH));
            }
        }
    }

    private void setSpinner(final int textArrayOptionResId, final int textViewResId, final String preferenceId) {

        final Spinner spinner = findViewById(textViewResId);
        if (spinner == null) {
            return;
        }
        ArrayAdapter<CharSequence> arrayAdapter = ArrayAdapter.createFromResource(this, textArrayOptionResId, android.R.layout.simple_spinner_item);
        arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(arrayAdapter);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                PreUtils.put(context, preferenceId, position);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                PreUtils.put(context, preferenceId, 0);
            }
        });
        int selection = PreUtils.get(context, preferenceId, 0);
        if (selection < arrayAdapter.getCount()) {
            spinner.setSelection(selection);
        } else {
            spinner.setSelection(0);
        }
    }

    private void getAttributes() {

        final EditText editTextServerHost = findViewById(R.id.editText_server_host);
        serverAdr = editTextServerHost.getText().toString();
        if (!TextUtils.isEmpty(serverAdr)) {
            serverAdr = serverAdr.trim();
        }
        if (!TextUtils.isEmpty(serverAdr)) {
            PreUtils.put(context, Constant.CONTROL_REMOTE_ADDR, serverAdr);
        }
        final Spinner videoResolutionSpinner = findViewById(R.id.spinner_video_resolution);
        final Spinner videoBitrateSpinner = findViewById(R.id.spinner_video_bitrate);
        final Spinner delayControlSpinner = findViewById(R.id.delay_control_spinner);
        final Spinner videoFpsSpinner = findViewById(R.id.spinner_video_fps);
        final Switch a_Switch0 = findViewById(R.id.switch0);
        boolean no_control = a_Switch0.isChecked();
        final Switch a_Switch1 = findViewById(R.id.switch1);
        boolean nav = a_Switch1.isChecked();
        PreUtils.put(context, Constant.CONTROL_NO, no_control);
        PreUtils.put(context, Constant.CONTROL_NAV, nav);

        String resolutionOption = getResources().getStringArray(R.array.options_resolution_values)[videoResolutionSpinner.getSelectedItemPosition()];
        if (resolutionOption.contains("x")) {
            final String[] videoResolutions = resolutionOption.split("x");
            screenHeight = Integer.parseInt(videoResolutions[0]);
            screenWidth = Integer.parseInt(videoResolutions[1]);
            videoMaxSize = Math.max(screenHeight, screenWidth);
        } else {
            DisplayMetrics dm = new DisplayMetrics();
            getWindowManager().getDefaultDisplay().getRealMetrics(dm);
            screenHeight = Math.max(dm.heightPixels, dm.widthPixels);
            screenWidth = Math.min(dm.heightPixels, dm.widthPixels);
            videoMaxSize = 0;
        }
        videoBitrate = getResources().getIntArray(R.array.options_bitrate_values)[videoBitrateSpinner.getSelectedItemPosition()];
        if (videoFpsSpinner != null) {
            videoFps = getResources().getIntArray(R.array.options_fps_values)[videoFpsSpinner.getSelectedItemPosition()];
        }
        delayControl = getResources().getIntArray(R.array.options_delay_values)[delayControlSpinner.getSelectedItemPosition()];
    }

    private String[] getHistoryList() {
        String historyList = PreUtils.get(context, Constant.HISTORY_LIST_KEY, "");
        if (TextUtils.isEmpty(historyList)) {
            return new String[]{};
        }
        try {
            JSONArray historyJson = new JSONArray(historyList);
            String[] retList = new String[historyJson.length()];
            for (int i = 0; i < historyJson.length(); i++) {
                retList[i] = historyJson.get(i).toString();
            }
            return retList;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return new String[]{};
    }

    /**
     * 保存设备历史连接记录
     */
    private boolean saveHistory(String device) {
        if (headlessMode) {
            // 无头模式不保存记录
            return false;
        }
        JSONArray historyJson = new JSONArray();
        String[] historyList = getHistoryList();
        if (historyList.length == 0) {
            historyJson.put(device);
        } else {
            try {
                historyJson.put(0, device);
            } catch (JSONException e) {
                e.printStackTrace();
            }
            // 最多记录 30 个
            int count = Math.min(historyList.length, 30);
            for (int i = 0; i < count; i++) {
                if (!historyList[i].equals(device)) {
                    historyJson.put(historyList[i]);
                }
            }
        }
        try {
            return PreUtils.put(context, Constant.HISTORY_LIST_KEY, historyJson.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    private void swapDimensions() {
        int temp = screenHeight;
        screenHeight = screenWidth;
        screenWidth = temp;
    }

    @SuppressLint("ClickableViewAccessibility")
    private void start_screen_copy_magic() {
        setContentView(R.layout.surface);
        final View decorView = getWindow().getDecorView();
        decorView.setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        surfaceView = findViewById(R.id.decoder_surface);
        surface = surfaceView.getHolder().getSurface();
        final LinearLayout nav_bar = findViewById(R.id.nav_button_bar);
        if (PreUtils.get(context, Constant.CONTROL_NAV, false) &&
                !PreUtils.get(context, Constant.CONTROL_NO, false)) {
            nav_bar.setVisibility(LinearLayout.VISIBLE);
        } else {
            nav_bar.setVisibility(LinearLayout.GONE);
        }
        linearLayout = findViewById(R.id.container1);
        setupMirrorActionMenu();
        start_Scrcpy_service();
    }


//    protected String wifiIpAddress() {

    /// /https://stackoverflow.com/questions/6064510/how-to-get-ip-address-of-the-device-from-code
//        try {
//            InetAddress ipv4 = null;
//            InetAddress ipv6 = null;
//            Enumeration<NetworkInterface> en = NetworkInterface.getNetworkInterfaces();
//            if (en != null) {
//                while (en.hasMoreElements()) {
//                    NetworkInterface int_f = en.nextElement();
//                    for (Enumeration<InetAddress> enumIpAddr = int_f
//                            .getInetAddresses(); enumIpAddr.hasMoreElements(); ) {
//                        InetAddress inetAddress = enumIpAddr.nextElement();
//                        if (inetAddress instanceof Inet6Address) {
//                            ipv6 = inetAddress;
//                            continue;
//                        }
//                        if (inetAddress.isLoopbackAddress() && inetAddress instanceof Inet4Address) {
//                            ipv4 = inetAddress;
//                            continue;
//                        }
//                        return inetAddress.getHostAddress();
//                    }
//                }
//            }
//            if (ipv6 != null) {
//                return ipv6.getHostAddress();
//            }
//            if (ipv4 != null) {
//                return ipv4.getHostAddress();
//            }
//        } catch (Exception ex) {
//            ex.printStackTrace();
//        }
//        return "127.0.0.1";
//    }
    private void start_Scrcpy_service() {
        Intent intent = new Intent(this, Scrcpy.class);
        startService(intent);
        bindService(intent, serviceConnection, Context.BIND_AUTO_CREATE);
    }

    @SuppressLint("SourceLockedOrientationActivity")
    @Override
    public void loadNewRotation() {
        if (first_time) {
            first_time = false;
        }
        try {
            // 可能会导致重复解绑，所以捕获异常
            unbindService(serviceConnection);
        } catch (Exception e) {
            e.printStackTrace();
        }
        serviceBound = false;
        result_of_Rotation = true;
        landscape = !landscape;
        swapDimensions();
        if (landscape) {
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
        } else {
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT);
        }
    }

    @Override
    public void errorDisconnect() {
        // 必须退出
        // 退出重连
        Dialog.displayDialog(this, getString(R.string.disconnect),
                getString(R.string.disconnect_ask), () -> {
                    if (serviceBound) {
                        showMainView();
                        first_time = true;
                    } else {
                        MainActivity.this.finish();
                    }
                }, false);
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (resumeScrcpy) {
            // 返回到主页面，属于用户主动断开场景
            showMainView(true);
            first_time = true;
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.d("Scrcpy", "onStart: " + serviceBound);
        if (resumeScrcpy) {
            if (!serviceBound) {
                resumeScrcpy = false;
                connectScrcpyServer(PreUtils.get(context, Constant.CONTROL_REMOTE_ADDR, ""));
            }
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.d("Scrcpy", "onPause: " + serviceBound);
        if (serviceBound && scrcpy != null) {
            scrcpy.pause();
            resumeScrcpy = true;
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (!first_time && !result_of_Rotation) {
            final View decorView = getWindow().getDecorView();
            decorView.setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
            if (serviceBound) {
                // 黑屏无需修复， 因为只是自带的配置问题
                linearLayout = findViewById(R.id.container1);
                scrcpy.resume();
            }
        }
        if (resumeScrcpy && !result_of_Rotation && scrcpy != null) {
            scrcpy.resume();
        }
        resumeScrcpy = false;  // 两处都要resumeScrcpy设置为false
        result_of_Rotation = false;
    }

    @Override
    public void onBackPressed() {
        if (timestamp == 0) {
            if (serviceBound) {
                timestamp = SystemClock.uptimeMillis();
                Toast.makeText(context, "Press again to exit", Toast.LENGTH_SHORT).show();
            } else {
                finish();
            }
        } else {
            long now = SystemClock.uptimeMillis();
            if (now < timestamp + 1000) {
                timestamp = 0;
                if (serviceBound) {
                    showMainView(true);
                    first_time = true;
                } else {
                    finish();
                }
            }
            timestamp = 0;
        }
    }

    @Override
    public void onSensorChanged(SensorEvent sensorEvent) {
        if (sensorEvent.sensor.getType() == Sensor.TYPE_PROXIMITY) {
            if (sensorEvent.values[0] == 0) {
                if (serviceBound) {
                    // 该事件会使远程手机 按下电源键，触发方式：按住距离传感器，然后点击屏幕即可锁屏
                    // 发送横竖屏会导致抬起事件无效
                    // scrcpy.sendKeyevent(28);
                }
            } else {
                if (serviceBound) {
                    // 发送横竖屏会导致抬起事件无效
                    // scrcpy.sendKeyevent(29);
                }
            }
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int i) {

    }


    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private GradientDrawable roundedBg(int color, float radiusDp) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(dp((int) radiusDp));
        drawable.setStroke(dp(1), Color.rgb(230, 233, 239));
        return drawable;
    }

    private TextView makeText(String text, int sp, int color, int style) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextSize(sp);
        tv.setTextColor(color);
        tv.setGravity(Gravity.CENTER_VERTICAL);
        tv.setTypeface(null, style);
        return tv;
    }

    private Button makeSmallButton(String text) {
        Button button = new Button(this);
        button.setText(text);
        button.setAllCaps(false);
        button.setTextSize(13);
        button.setPadding(dp(8), 0, dp(8), 0);
        return button;
    }

    private void setupSmartUi() {
        refreshDeviceLists();

        View saveButton = findViewById(R.id.button_save_device);
        if (saveButton != null) {
            saveButton.setOnClickListener(v -> {
                getAttributes();
                if (!TextUtils.isEmpty(serverAdr)) {
                    saveHistory(serverAdr);
                    refreshDeviceLists();
                    Toast.makeText(context, "Đã lưu thiết bị", Toast.LENGTH_SHORT).show();
                }
            });
        }

        View checkButton = findViewById(R.id.button_check_adb);
        if (checkButton != null) {
            checkButton.setOnClickListener(v -> checkCurrentDevice());
        }

        View install = findViewById(R.id.button_install_apk);
        if (install != null) {
            install.setOnClickListener(v -> chooseApkFile());
        }
        View push = findViewById(R.id.button_push_file);
        if (push != null) {
            push.setOnClickListener(v -> chooseFileToPush());
        }
        View screenshot = findViewById(R.id.button_screenshot);
        if (screenshot != null) {
            screenshot.setOnClickListener(v -> captureScreenshot());
        }
        View record = findViewById(R.id.button_record);
        if (record != null) {
            record.setOnClickListener(v -> toggleScreenRecord());
        }
    }

    private void refreshDeviceLists() {
        renderSavedDeviceCards();
        renderTailscaleCards();
    }

    private void renderSavedDeviceCards() {
        LinearLayout list = findViewById(R.id.saved_device_list);
        if (list == null) {
            return;
        }
        list.removeAllViews();
        String[] devices = getHistoryList();
        if (devices.length == 0) {
            TextView empty = makeText("Chưa có thiết bị. Nhập IP bên dưới rồi bấm + hoặc KẾT NỐI.", 14, Color.rgb(100, 100, 100), 0);
            empty.setPadding(dp(14), dp(14), dp(14), dp(14));
            empty.setBackground(roundedBg(Color.WHITE, 12));
            list.addView(empty, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
            return;
        }
        for (int i = 0; i < devices.length; i++) {
            addDeviceCard(list, i + 1, devices[i], true);
        }
    }

    private void renderTailscaleCards() {
        LinearLayout list = findViewById(R.id.tailscale_device_list);
        if (list == null) {
            return;
        }
        list.removeAllViews();
        String[] devices = getHistoryList();
        if (devices.length == 0) {
            TextView empty = makeText("Danh sách này dùng chung với thiết bị đã lưu. Hỗ trợ IP Tailscale dạng 100.x.x.x hoặc IP LAN.", 14, Color.rgb(100, 100, 100), 0);
            empty.setPadding(dp(12), dp(12), dp(12), dp(12));
            list.addView(empty, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
            return;
        }
        for (int i = 0; i < devices.length; i++) {
            addDeviceCard(list, i + 1, devices[i], false);
        }
    }

    private void addDeviceCard(LinearLayout list, int index, String device, boolean withActions) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(16), dp(14), dp(16), dp(14));
        card.setBackground(roundedBg(Color.WHITE, 12));

        String[] info = Util.getServerHostAndPort(device);
        TextView title = makeText(String.format(Locale.US, "#%02d - %s", index, info[0]), 20, Color.rgb(32, 33, 36), android.graphics.Typeface.BOLD);
        TextView sub = makeText(info[0] + " · Port: " + info[1] + " · Tailscale / LAN", 15, Color.rgb(120, 120, 120), 0);
        sub.setPadding(0, dp(4), 0, 0);
        card.addView(title, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        card.addView(sub, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        actions.setPadding(0, dp(12), 0, 0);
        Button connect = makeSmallButton("Kết nối");
        connect.setOnClickListener(v -> setServerAndConnect(device));
        Button check = makeSmallButton("Kiểm tra");
        check.setOnClickListener(v -> {
            setServerText(device);
            checkCurrentDevice();
        });
        actions.addView(connect, new LinearLayout.LayoutParams(0, dp(42), 1));
        LinearLayout.LayoutParams lpCheck = new LinearLayout.LayoutParams(0, dp(42), 1);
        lpCheck.leftMargin = dp(8);
        actions.addView(check, lpCheck);
        if (withActions) {
            Button menu = makeSmallButton("⋮");
            menu.setOnClickListener(v -> {
                setServerText(device);
                Toast.makeText(context, "Đã chọn " + device, Toast.LENGTH_SHORT).show();
            });
            LinearLayout.LayoutParams lpMenu = new LinearLayout.LayoutParams(dp(52), dp(42));
            lpMenu.leftMargin = dp(8);
            actions.addView(menu, lpMenu);
        }
        card.addView(actions, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = dp(12);
        list.addView(card, lp);
    }

    private void setServerText(String device) {
        EditText edit = findViewById(R.id.editText_server_host);
        if (edit != null) {
            edit.setText(device);
        }
        serverAdr = device;
        lastConnectedServer = device;
        PreUtils.put(context, Constant.CONTROL_REMOTE_ADDR, device);
    }

    private void setServerAndConnect(String device) {
        setServerText(device);
        getAttributes();
        connectScrcpyServer(device);
    }

    private String getTargetServerAddress() {
        EditText edit = findViewById(R.id.editText_server_host);
        String target = null;
        if (edit != null) {
            target = edit.getText().toString();
        }
        if (TextUtils.isEmpty(target)) {
            target = serverAdr;
        }
        if (TextUtils.isEmpty(target)) {
            target = lastConnectedServer;
        }
        if (TextUtils.isEmpty(target)) {
            target = PreUtils.get(context, Constant.CONTROL_REMOTE_ADDR, "");
        }
        return target == null ? "" : target.trim();
    }

    private String ensureAdbConnected() throws Exception {
        String target = getTargetServerAddress();
        if (TextUtils.isEmpty(target)) {
            throw new IllegalStateException("Chưa chọn IP thiết bị");
        }
        String[] info = Util.getServerHostAndPort(target);
        String serial = info[0] + ":" + info[1];
        boolean serverIsRunning = AdbHelper.checkAdbServer();
        if (!serverIsRunning || !AdbHelper.isRunning()) {
            AdbHelper.restartAdb();
            AdbHelper.waitForRunning(5);
        }
        AdbHelper.adbCmd(App.mContext, "connect", serial);
        return serial;
    }

    private interface AdbAction {
        String run() throws Exception;
    }

    private void runAdbAction(String title, AdbAction action) {
        Progress.showDialog(MainActivity.this, title);
        ThreadUtils.workPost(() -> {
            String result;
            boolean success = true;
            try {
                result = action.run();
                if (result == null) {
                    result = "Hoàn tất";
                }
            } catch (Exception e) {
                success = false;
                result = e.getMessage() == null ? e.toString() : e.getMessage();
            }
            final String message = result;
            final boolean ok = success;
            ThreadUtils.post(() -> {
                Progress.closeDialog();
                Toast.makeText(context, (ok ? "OK: " : "Lỗi: ") + message, Toast.LENGTH_LONG).show();
            });
        });
    }

    private void checkCurrentDevice() {
        runAdbAction("Đang kiểm tra ADB …", () -> {
            String serial = ensureAdbConnected();
            String out = AdbHelper.adbCmd(App.mContext, "-s", serial, "shell", "getprop", "ro.product.model");
            return TextUtils.isEmpty(out) ? "Đã kết nối " + serial : serial + " · " + out;
        });
    }

    private void chooseApkFile() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        startActivityForResult(intent, REQ_INSTALL_APK);
    }

    private void chooseFileToPush() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        startActivityForResult(intent, REQ_PUSH_FILE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) {
            return;
        }
        Uri uri = data.getData();
        if (requestCode == REQ_INSTALL_APK) {
            installApk(uri);
        } else if (requestCode == REQ_PUSH_FILE) {
            pushFile(uri);
        }
    }

    private void installApk(Uri uri) {
        runAdbAction("Đang cài APK …", () -> {
            String serial = ensureAdbConnected();
            File local = copyUriToCache(uri, "selected.apk");
            String out = AdbHelper.adbCmd(App.mContext, "-s", serial, "install", "-r", local.getAbsolutePath());
            if (TextUtils.isEmpty(out)) {
                out = "Đã gửi lệnh cài APK";
            }
            return out;
        });
    }

    private void pushFile(Uri uri) {
        runAdbAction("Đang chuyển file …", () -> {
            String serial = ensureAdbConnected();
            File local = copyUriToCache(uri, "file.bin");
            String remote = "/sdcard/Download/" + local.getName();
            String out = AdbHelper.adbCmd(App.mContext, "-s", serial, "push", local.getAbsolutePath(), remote);
            if (TextUtils.isEmpty(out)) {
                out = "Đã chuyển tới " + remote;
            }
            return out;
        });
    }

    private void captureScreenshot() {
        runAdbAction("Đang chụp màn hình …", () -> {
            String serial = ensureAdbConnected();
            String name = "scrcpy_" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date()) + ".png";
            String remote = "/sdcard/Pictures/" + name;
            File dir = new File(getExternalFilesDir(null), "screenshots");
            if (!dir.exists()) {
                dir.mkdirs();
            }
            File local = new File(dir, name);
            AdbHelper.adbCmd(App.mContext, "-s", serial, "shell", "mkdir", "-p", "/sdcard/Pictures");
            AdbHelper.adbCmd(App.mContext, "-s", serial, "shell", "screencap", "-p", remote);
            String out = AdbHelper.adbCmd(App.mContext, "-s", serial, "pull", remote, local.getAbsolutePath());
            if (TextUtils.isEmpty(out)) {
                out = "Đã lưu " + local.getAbsolutePath();
            }
            return out;
        });
    }

    private void toggleScreenRecord() {
        if (recordingRemotePath == null) {
            runAdbAction("Bắt đầu quay màn hình …", () -> {
                String serial = ensureAdbConnected();
                String name = "scrcpy_record_" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date()) + ".mp4";
                recordingRemotePath = "/sdcard/Movies/" + name;
                AdbHelper.adbCmd(App.mContext, "-s", serial, "shell", "mkdir", "-p", "/sdcard/Movies");
                AdbHelper.adbCmd(App.mContext, "-s", serial, "shell", "sh", "-c", "screenrecord --time-limit 180 " + recordingRemotePath + " >/dev/null 2>&1 &");
                return "Đang quay tối đa 180 giây. Bấm Quay màn hình lần nữa để dừng.";
            });
        } else {
            runAdbAction("Dừng quay màn hình …", () -> {
                String serial = ensureAdbConnected();
                AdbHelper.adbCmd(App.mContext, "-s", serial, "shell", "pkill", "-2", "screenrecord");
                Thread.sleep(1200);
                File dir = new File(getExternalFilesDir(null), "records");
                if (!dir.exists()) {
                    dir.mkdirs();
                }
                String name = recordingRemotePath.substring(recordingRemotePath.lastIndexOf('/') + 1);
                File local = new File(dir, name);
                String out = AdbHelper.adbCmd(App.mContext, "-s", serial, "pull", recordingRemotePath, local.getAbsolutePath());
                recordingRemotePath = null;
                if (TextUtils.isEmpty(out)) {
                    out = "Đã lưu " + local.getAbsolutePath();
                }
                return out;
            });
        }
    }

    private File copyUriToCache(Uri uri, String fallbackName) throws Exception {
        String name = getFileName(uri);
        if (TextUtils.isEmpty(name)) {
            name = fallbackName;
        }
        name = sanitizeFileName(name);
        File dir = new File(getCacheDir(), "adb_actions");
        if (!dir.exists()) {
            dir.mkdirs();
        }
        File out = new File(dir, System.currentTimeMillis() + "_" + name);
        try (InputStream in = getContentResolver().openInputStream(uri); OutputStream output = new FileOutputStream(out)) {
            if (in == null) {
                throw new IOException("Không mở được file đã chọn");
            }
            byte[] buffer = new byte[8192];
            int len;
            while ((len = in.read(buffer)) != -1) {
                output.write(buffer, 0, len);
            }
        }
        return out;
    }

    private String getFileName(Uri uri) {
        String result = null;
        if ("content".equals(uri.getScheme())) {
            try (Cursor cursor = getContentResolver().query(uri, null, null, null, null)) {
                if (cursor != null && cursor.moveToFirst()) {
                    int index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                    if (index >= 0) {
                        result = cursor.getString(index);
                    }
                }
            } catch (Exception ignore) {
            }
        }
        if (result == null) {
            result = uri.getLastPathSegment();
        }
        return result;
    }

    private String sanitizeFileName(String name) {
        return name.replaceAll("[^a-zA-Z0-9._-]", "_");
    }

    private void setupMirrorActionMenu() {
        View menuButton = findViewById(R.id.action_menu_button);
        View menuPanel = findViewById(R.id.action_menu_panel);
        if (menuButton == null || menuPanel == null) {
            return;
        }
        menuButton.setOnClickListener(v -> {
            menuPanel.setVisibility(menuPanel.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE);
        });
        View install = findViewById(R.id.menu_install_apk);
        if (install != null) {
            install.setOnClickListener(v -> {
                menuPanel.setVisibility(View.GONE);
                chooseApkFile();
            });
        }
        View push = findViewById(R.id.menu_push_file);
        if (push != null) {
            push.setOnClickListener(v -> {
                menuPanel.setVisibility(View.GONE);
                chooseFileToPush();
            });
        }
        View screenshot = findViewById(R.id.menu_screenshot);
        if (screenshot != null) {
            screenshot.setOnClickListener(v -> {
                menuPanel.setVisibility(View.GONE);
                captureScreenshot();
            });
        }
        View record = findViewById(R.id.menu_record);
        if (record != null) {
            record.setOnClickListener(v -> {
                menuPanel.setVisibility(View.GONE);
                toggleScreenRecord();
            });
        }
    }

    private void connectScrcpyServer(String serverAdr) {
        if (!TextUtils.isEmpty(serverAdr)) {
            lastConnectedServer = serverAdr;
            saveHistory(serverAdr);  // 保存到历史记录
            String[] serverInfo = Util.getServerHostAndPort(serverAdr);
            String serverHost = serverInfo[0];
            int serverPort = Integer.parseInt(serverInfo[1]);
            int localForwardPort = Scrcpy.LOCAL_FORWART_PORT;

            Progress.showDialog(MainActivity.this, getString(R.string.please_wait));
            ThreadUtils.workPost(() -> {
                AdbHelper.writeAssetsJarServer(App.mContext);
                SendCommands.CmdStatus sendStatus = sendCommands.SendAdbCommands(context, serverHost,
                        serverPort,
                        localForwardPort,
                        Scrcpy.LOCAL_IP,
                        videoBitrate, videoMaxSize, videoFps);
                if (sendStatus == SendCommands.CmdStatus.SUCCESS) {
                    ThreadUtils.post(() -> {
                        if (!MainActivity.this.isFinishing()) {
                            // 进入主线程
                            Log.e("Scrcpy: ", "from startButton");
                            start_screen_copy_magic();
                        }
                    });
                } else {
                    ThreadUtils.post(Progress::closeDialog);
                    Toast.makeText(context, "Network OR ADB connection failed", Toast.LENGTH_SHORT).show();
                    connectExitExt();
                }
            });
        } else {
            Toast.makeText(context, "Server Address Empty", Toast.LENGTH_SHORT).show();
            connectExitExt();
        }
    }

    /**
     * 连接成功了，而且成功的显示了画面出来
     */
    protected void connectSuccessExt() {
        Dialog.closeDialogs();
    }

    protected void connectExitExt() {
        this.connectExitExt(false);
    }

    /**
     * 连接失败的额外处理
     */
    protected void connectExitExt(boolean userDisconnect) {
        if (!userDisconnect) {  // userDisconnect : 用户主动断开连接
            // 如果自动断开了端口连接，在系统恢复时，重启adb，避免
            // 警告！！！ 重启将会导致 adb 配对过程失效，从而无法连接新设备，需要更智能的重启机制
            // AdbHelper.restartAdb();
        }
        if (headlessMode && !resumeScrcpy && !result_of_Rotation) {
            if (!userDisconnect) {
                Dialog.displayDialog(this, getString(R.string.connect_faild),
                        getString(R.string.connect_faild_ask), () -> {
                            // 重试连接
                            connectScrcpyServer(PreUtils.get(context, Constant.CONTROL_REMOTE_ADDR, ""));
                        }, () -> {
                            // 取消重试
                            finishAndRemoveTask();
                        });
            } else {
                finishAndRemoveTask();
            }
        }
//        Log.i("Scrcpy", "headlessMode： " + headlessMode +
//                " ,resumeScrcpy: " + resumeScrcpy + " ,result_of_Rotation: " + result_of_Rotation);
    }

}
