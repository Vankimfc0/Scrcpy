#!/usr/bin/env bash
set -euo pipefail
chmod +x ./gradlew
./gradlew assembleScrcpyDebug
ls -lah app/build/outputs/apk/scrcpy/debug/
