# Cập nhật chức năng

Bản này sửa các điểm sau:

- Các tab dưới cùng có thể bấm để nhảy tới từng mục: Thiết bị, Kết nối, Tailscale, Cài đặt.
- Nút ba chấm trên từng thiết bị mở menu chọn chức năng thật: Kết nối, Cài APK, Chuyển file, Chụp màn hình, Quay màn hình, Tắt/Bật màn hình, Xóa khỏi danh sách.
- Thêm tùy chọn trong mục Cài đặt thiết bị: **Tắt màn hình thiết bị khi kết nối**.
- Thêm nút trong menu nổi khi đang mirror: **Tắt/Bật màn hình**.
- Chức năng tắt màn hình được truyền xuống scrcpy-server nội bộ, không dùng Termux.
