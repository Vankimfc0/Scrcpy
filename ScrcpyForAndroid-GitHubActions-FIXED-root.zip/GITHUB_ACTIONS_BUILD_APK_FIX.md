# Sửa lỗi không thấy mục Build APK trên GitHub Actions

Lý do thường gặp:

1. Bạn upload nguyên file `.zip` lên GitHub thay vì giải nén rồi upload toàn bộ source.
2. Thư mục `.github/workflows` nằm sai vị trí, ví dụ: `ScrcpyForAndroid-custom/.github/workflows` thay vì nằm ngay ở root repo.
3. GitHub chưa bật Actions cho repository.
4. File workflow chưa nằm trên nhánh mặc định `main` hoặc `master`.

## Cách kiểm tra đúng

Ở trang repo GitHub, bạn phải thấy đường dẫn này ngay tại root:

```text
.github/workflows/build-apk.yml
```

Không được là:

```text
ScrcpyForAndroid-custom/.github/workflows/build-apk.yml
```

## Cách sửa nhanh nhất

1. Giải nén file zip này.
2. Mở thư mục vừa giải nén.
3. Upload TOÀN BỘ NỘI DUNG BÊN TRONG thư mục lên GitHub, không upload cả thư mục mẹ.
4. Vào tab `Actions`.
5. Nếu GitHub hỏi bật Actions, bấm `I understand my workflows, go ahead and enable them`.
6. Chọn workflow `Build APK`.
7. Bấm `Run workflow`.
8. Sau khi chạy xong, tải artifact `ScrcpyForAndroid-enhanced-debug-apk`.

## Nếu vẫn không thấy Build APK

Tạo thủ công file workflow:

1. Trong GitHub repo, bấm `Add file` -> `Create new file`.
2. Ở ô tên file nhập đúng:

```text
.github/workflows/build-apk.yml
```

3. Copy nội dung từ file `.github/workflows/build-apk.yml` trong gói này vào.
4. Bấm `Commit changes`.
5. Quay lại tab `Actions`.
