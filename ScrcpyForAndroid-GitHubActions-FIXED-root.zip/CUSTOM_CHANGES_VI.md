# Scrcpy Remote Enhanced - ghi chú bản chỉnh sửa

Bản này được chỉnh sửa từ ScrcpyForAndroid 1.4.1 theo giao diện trong ảnh người dùng gửi.

## Đã thêm / chỉnh sửa

- Giao diện tiếng Việt dạng card giống ảnh:
  - `Thiết bị đã lưu`
  - `Kết nối nhanh`
  - `Cài đặt thiết bị`
  - `Công cụ nhanh`
  - `Tailscale / LAN`
- Danh sách thiết bị đã lưu hiển thị dạng card với IP, port 5555, nút `Kết nối`, `Kiểm tra`.
- Menu nổi trong màn hình mirror:
  - `Cài APK`
  - `Chuyển file`
  - `Chụp màn hình`
  - `Quay màn hình`
- Thêm chức năng ADB nội bộ, không phụ thuộc Termux:
  - `adb connect`
  - `adb install -r`
  - `adb push`
  - `screencap` + `adb pull`
  - `screenrecord` + `adb pull`
- Thêm lựa chọn FPS và truyền FPS xuống scrcpy-server.
- Giữ codec H.264/AVC để tương thích với decoder hiện tại của project.
- Cập nhật GitHub Actions để upload cả APK debug và release.

## Cách build APK

Máy build cần có Android Studio hoặc Android SDK + Gradle có mạng lần đầu để tải Gradle/AGP.

```bash
chmod +x gradlew
./gradlew assembleScrcpyDebug
```

APK debug nằm ở:

```text
app/build/outputs/apk/scrcpy/debug/*.apk
```

Build release:

```bash
./gradlew assembleScrcpyRelease
```

Nếu không có keystore, release có thể chưa được ký. Bản debug dùng để test trực tiếp.

## Lưu ý sử dụng

- Thiết bị bị điều khiển phải bật ADB TCP/IP, thường là port `5555`.
- Có thể nhập IP LAN hoặc IP Tailscale.
- Với thiết bị Android mới, lần đầu kết nối ADB vẫn cần xác nhận RSA / pairing theo cơ chế của máy đó.
- `Chụp màn hình` lưu vào thư mục app: `Android/data/org.client.scrcpy/files/screenshots`.
- `Quay màn hình` lưu vào thư mục app: `Android/data/org.client.scrcpy/files/records`.
