package org.server.scrcpy;

public class Options {
    private int maxSize;
    private int bitRate;
    private int frameRate = 60;
    private boolean tunnelForward;
    private boolean turnScreenOffOnStart;

    public int getMaxSize() {
        return maxSize;
    }

    public void setMaxSize(int maxSize) {
        this.maxSize = maxSize;
    }

    public int getBitRate() {
        return bitRate;
    }

    public void setBitRate(int bitRate) {
        this.bitRate = bitRate;
    }

    public int getFrameRate() {
        return frameRate;
    }

    public void setFrameRate(int frameRate) {
        this.frameRate = frameRate;
    }

    public boolean isTunnelForward() {
        return tunnelForward;
    }

    public boolean isTurnScreenOffOnStart() {
        return turnScreenOffOnStart;
    }

    public void setTurnScreenOffOnStart(boolean turnScreenOffOnStart) {
        this.turnScreenOffOnStart = turnScreenOffOnStart;
    }

    public void setTunnelForward(boolean tunnelForward) {
        this.tunnelForward = tunnelForward;
    }
}
