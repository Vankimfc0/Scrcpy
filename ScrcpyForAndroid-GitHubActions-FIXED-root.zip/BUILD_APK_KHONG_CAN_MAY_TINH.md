# Build APK khong can tu build tren may tinh

Ban nay da co san GitHub Actions. Ban chi can dua source len GitHub, GitHub se build APK giup ban.

## Cach lam tren dien thoai

1. Mo github.com va dang nhap.
2. Tao repository moi, vi du: `scrcpy-enhanced`.
3. Upload toan bo file trong thu muc nay len repository.
4. Vao tab **Actions**.
5. Chon workflow **Build APK**.
6. Bam **Run workflow**.
7. Sau khi workflow chay xong, mo run do va tai artifact **ScrcpyForAndroid-enhanced-debug-apk**.
8. Giai nen artifact, trong do co file `.apk` de cai tren Android.

## Neu Actions bi loi

Gui lai cho minh file log cua workflow. Minh se sua workflow/source theo log do.

## Luu y

- APK debug dung de cai va test truc tiep.
- App khong dung Termux.
- May bi dieu khien van phai bat ADB wireless / ADB TCP/IP va chap nhan RSA khi ket noi lan dau.
